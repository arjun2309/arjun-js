// functions
// 1.function declaration
// simple function with arguments
// function forPositive(num){
//     return num>0
// }

// forPositive()

// function forPositive(num,num1){
//     console.log(num+num1)
// }

// forPositive(2,5)

// function abc(){
//     console.log("welcome")
// }
// abc()

// multi arguments 
// function multi(a,b){
//     return a*b
// }
// console.log(multi(4,5))

// hoisting


// console.log(add(4,5))
// function add(a,b){
//     return a+b
// }

// default parameters

// function default1(name = "arjun",role = "developer"){
//     console.log('hi',name,role)
// }
// default1()


// let foreven = function(num){
//     return num%2==0
// }

// console.log(foreven(23))


var for_even = function(num){
    return num%2==0
}

console.log(for_even(20))