package com.dbconnection.service;

import com.dbconnection.dto.CustommerDto;

public interface CustommerInter {
	
	public String SaveCustommer(CustommerDto custommerDto);

}
