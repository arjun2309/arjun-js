//package com.dbconnection.service;
//
//import org.springframework.beans.factory.annotation.Autowired;    
//import org.springframework.stereotype.Service;
////import com.dbconnection.dto.ProductDto;
////import com.dbconnection.model.Product;
////import com.dbconnection.repository.ProductRepositoryService;
//
//import com.dbconnection.dto.EmployeeMonthAttedenceDto;
//import com.dbconnection.model.EmployeeMonthAttedence;
////import com.dbconnection.repository.EmployeeMonthlyAttedenceService;
//import com.dbconnection.repository.EmployeeMonthlyAttedencejpaService;
//
//@Service
//public class ProductServiceImpl implements ProductService {
//	@Autowired
//	private EmployeeMonthlyAttedencejpaService hjpaAttedencejpaService;
//
//	@Override
//	public String SaveAttedence(EmployeeMonthAttedenceDto attedenceDto) {
//		
//		EmployeeMonthAttedence aays=new EmployeeMonthAttedence();
//		aays.setId(attedenceDto.getId());
//		aays.setEmployeID(attedenceDto.getEmployeeId());
//		aays.setMonths(attedenceDto.getMonth());
//		aays.setDayWorking(attedenceDto.getWorkingDays());
//		hjpaAttedencejpaService.save(aays);
//		
//		return "saveed";
//	}
//	
//	
//	
//	
//	
////	@Autowired
////	private ProductRepositoryService productRepositoryService;
//
////	@Override
////	public String saveProductInfo(ProductDto productDto) { //inga dto val airundhu ara data sae pannuvom
////	
////		Product product=new Product();
////		
////		product.setId(productDto.getId());
////		product.setName(productDto.getName());
////		Product msg=productRepositoryService.save(product); 
////		
////		if(msg!=null) {
////			return "sucess saved";
////		}
////		return "failed" ;
////		
////	}
//
//}
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
//
////
//////model object create
////		Product product=new Product();
////		//dto datas model ku set panni irukom  (Dto get -> model set)
////		product.setId(productDto.getId()); ///inga dto la irundhu eduthu product ku set pannurom
////		product.setName(productDto.getName());
////		
//////			Product msg=productRepositoryService.save(product); ///inga save aittu productmodel return pannum
//////			if(msg!=null) {
//////			return  "sucess";
//////			}
//////			return "failed";
////		return productRepositoryService.save(product);