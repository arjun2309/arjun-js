// conditional statements

// if else 
// let a = 23
// if(a<=23){
//     console.log("a is greater than 23")}
// else{
//     console.log("a is less than 23")}


// if else if else
// let c = 20
// let d = 20
// if (c>d)
//     console.log("c is greater than d")
// else if (c == d)
//     console.log("c is equal to d").
// else
//     console.log("c is less than d")



// let s = false
// let m = false

// if(s){
//     console.log("condition is true")
// }
// else{
//     console.log("condition is false")
// }
// if else else if (and ,or,not operator)
let e = 50
let f = 25
let g = 30

if (e>f && g>f )
    console.log("e is greater than f ,g is greater than f")
else if (f==g || g==e)
    console.log("f is equal to g,g is equal to e")
else
    console.log("third is done")