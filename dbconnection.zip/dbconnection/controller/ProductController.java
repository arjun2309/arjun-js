//package com.dbconnection.controller;
//
//
//import org.springframework.beans.factory.annotation.Autowired;  
//import org.springframework.web.bind.annotation.RequestMapping;
//import org.springframework.web.bind.annotation.RestController;
//
//import com.dbconnection.dto.EmployeeMonthAttedenceDto;
//import com.dbconnection.dto.ProductDto;
////import com.dbconnection.model.Product;
//import com.dbconnection.service.ProductService;
//
//import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.PostMapping;
//
//
//@RestController
//@RequestMapping("/product")
//@CrossOrigin(origins = "http://localhost:3000")
//public class ProductController {
//	@Autowired
//	private ProductService productService;
//	
////	@PostMapping("/save")
////	public String saveProduct(@RequestBody ProductDto productDto) {
////		
////	return productService.saveProductInfo(productDto);
////	}
//	
//	@PostMapping("/employeSave")
//	public String saveattedence(@RequestBody EmployeeMonthAttedenceDto attedenceDto) {
//		productService.SaveAttedence(attedenceDto);
//	return"aded airuchi";	
//	}
//	
//
//}
//
//
//
//
//
//
//
////Product product=	productService.saveProductInfo(productDto);
////if(product!=null) {
////	return "sucess";
////}