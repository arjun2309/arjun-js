//package com.dbconnection.repository;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//import org.springframework.stereotype.Repository;
//
//import com.dbconnection.dto.EmployeeMonthAttedenceDto;
//import com.dbconnection.model.EmployeeMonthAttedence;
//@Repository
//public interface EmployeeMonthlyAttedencejpaService extends JpaRepository<EmployeeMonthAttedence,Long> {
//
//}
