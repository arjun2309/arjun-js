// // Module


 import Car ,{fillGas as fill,repair} from './module.js'

let car1 = new Car()
car1.drive()
fill()
repair()