//package com.dbconnection.service;
//
//import com.dbconnection.dto.EmployeeMonthAttedenceDto;
//import com.dbconnection.dto.ProductDto;
//import com.dbconnection.model.EmployeeMonthAttedence;  
////import com.dbconnection.model.Product;
//
//public interface ProductService {
//
////	public String saveProductInfo(ProductDto productDto);
//	
//	public String SaveAttedence(EmployeeMonthAttedenceDto attedenceDto);
//
//}
