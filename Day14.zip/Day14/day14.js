// loops
// let a = 5
// let i 
// for (i=1;i<49;i++){  
    
//     console.log(a)
    
    
// }
// a = ["apple","banana","cherry","orange","watermelon","lemon"]
// for (let i = 3;i>0;i--){
//     console.log(a[i])
// }
// console.log(i)

// while loop

// let a 
// console.log("while loops")
// let a = 10
// while(a>1){
//     console.log(a)
//     }


// b = 0
// while(b<10){
//     b+=2
//     console.log(b)
//        b++;}

// do while
// do while is first print the value and next check the condition
// console.log('do while')
// i = 0
// do{
//     console.log(i)
//     i--
// }while(i>=1)

// break
i = 0
while (i<=10){
    i++;
    if (i==5){
        console.log("Loop stopped by break")
        continue
    }
    console.log(i)
   
}