package com.dbconnection.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dbconnection.dto.CustommerDto;
import com.dbconnection.model.CustommerModel;
import com.dbconnection.repository.CustommerJpaRepository;

@Service
public class CustommerServiceimpl  implements CustommerInter{
	
	@Autowired
	private CustommerJpaRepository custommerServic;

	@Override
	public String SaveCustommer(CustommerDto custommerDto) {
		
		
		CustommerModel custommerModel=new CustommerModel();
		
		custommerModel.setId(custommerDto.getId());
		custommerModel.setCustommerName(custommerDto.getCustommerName());
		custommerModel.setEmail(custommerDto.getEmail());
		custommerModel.setMobileNumber(custommerDto.getMobileNumber());
		
		CustommerModel msg=	 custommerServic.save(custommerModel);
		
		
		if(msg!=null) {
			return "sucessfull";
		}
		return "failed";
	}
	
	
	

}
