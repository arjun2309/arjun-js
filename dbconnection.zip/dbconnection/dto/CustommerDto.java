package com.dbconnection.dto;

public class CustommerDto {
	private Long id;
	private String CustommerName;
	private String email;
	private long mobileNumber;
	public CustommerDto(Long id, String custommerName, String email, long mobileNumber) {
		super();
		this.id = id;
		CustommerName = custommerName;
		this.email = email;
		this.mobileNumber = mobileNumber;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getCustommerName() {
		return CustommerName;
	}
	public void setCustommerName(String custommerName) {
		CustommerName = custommerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public long getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(long mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	

}
