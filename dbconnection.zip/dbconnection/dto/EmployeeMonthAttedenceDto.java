//package com.dbconnection.dto;
//
//public class EmployeeMonthAttedenceDto {
//	private long id;
//	
//	private String EmployeeId;
//    private int workingDays;
//    private String month;
//	public EmployeeMonthAttedenceDto(long id, String employeeId, int workingDays, String month) {
//		super();
//		this.id = id;
//		EmployeeId = employeeId;
//		this.workingDays = workingDays;
//		this.month = month;
//	}
//	public long getId() {
//		return id;
//	}
//	public void setId(long id) {
//		this.id = id;
//	}
//	public String getEmployeeId() {
//		return EmployeeId;
//	}
//	public void setEmployeeId(String employeeId) {
//		EmployeeId = employeeId;
//	}
//	public int getWorkingDays() {
//		return workingDays;
//	}
//	public void setWorkingDays(int workingDays) {
//		this.workingDays = workingDays;
//	}
//	public String getMonth() {
//		return month;
//	}
//	public void setMonth(String month) {
//		this.month = month;
//	}
//    
//    
//
//
//}
