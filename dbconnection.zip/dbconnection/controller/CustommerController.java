package com.dbconnection.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import com.dbconnection.dto.CustommerDto;
import com.dbconnection.service.CustommerInter;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;


@RestController
public class CustommerController {
	
	@Autowired
	private CustommerInter custommerInter;
	
	@PostMapping("/savecustommer")
	public String SaveCustommer(@RequestBody CustommerDto entity) {
		return custommerInter.SaveCustommer(entity);
	}
	

}
